package exception;

public class ClickToCartException extends Exception {
    public ClickToCartException(String message) {
        super(message);
    }
}
